/* =========================================
   Offcanvas Script
   ========================================= */

// Target menu button & offcanvas
const menuBtn = document.getElementById('menuBtn');
const offcanvas = document.querySelector('.offcanvas');
const offcanvasLinks = document.querySelectorAll('.offcanvas a');

// Toggle offcanvas by menu toggler
menuBtn.addEventListener('click', () => offcanvas.classList.toggle('open'));

// Close offcanvas by link activating
offcanvasLinks.forEach(link => link.addEventListener('click', () => offcanvas.classList.remove('open')));




/* =========================================
   Top Button Script
   ========================================= */

// Target top button
const topBtn = document.getElementById('topBtn');

// Show top button after 300px scroll
window.addEventListener('scroll', () => topBtn.classList.toggle('visible', window.scrollY > 300));




/* =========================================
   Odometer Script
   ========================================= */

// Target stats items
const odometers = document.querySelectorAll('.odometer');

// Create odometer for stats item
const createOdometer = (el, value) => {
  
  // Instantiate odemeter
  const odometer = new Odometer({ el, value: 0, hasRun: false });
  
  // Enable odometer one time when nearby
  const callback = (entries, observer) => {
    entries.forEach((entry) => {
      if (entry.isIntersecting) {
        if (!odometer.hasRun) {
          odometer.update(value);
          odometer.hasRun = true;
        }
      }
    });
  };

  const options = { threshold: [0, 0.9] };
  
  const observer = new IntersectionObserver(callback, options);
  
  observer.observe(el);
};

// Create odometer for each stats item
odometers.forEach(el => createOdometer(el, el.textContent));




/* =========================================
   Form Script
   ========================================= */

/* Config email.js
******************
** [IMPORTANT NOTE]: This is not a secure way to define secret variables. Use `.env` file instead
** 
** [FUTURE NOTE]: Those API Keys / IDs are temporary and limited.
*****************
** If you faced some error, inform me or follow these steps:
** 1. Sign up at https://www.emailjs.com/
** 2. Create an Email Service + Email Template, paste your keys below.
** 3. Template variables: {{from_name}} {{from_email}} {{subject}} {{message}}
*/
const EMAILJS_PUBLIC_KEY  = 'z-ySKQFSqtPnuVE2o';
const EMAILJS_SERVICE_ID  = 'service_5hxg6rq';
const EMAILJS_TEMPLATE_ID = 'template_tph201n';
emailjs.init({ publicKey: EMAILJS_PUBLIC_KEY });

// Target elements
const toastContainer = document.getElementById('toastContainer');
const contactForm = document.getElementById('contactForm');
const submitBtn = contactForm.querySelector('[type="submit"]');

// Show toast
function showToast(type, title, msg) {

  // Create toast card
  const toast = document.createElement('div');
  toast.setAttribute('role', 'alert');

  // Style toast regarding type
  toast.className = 'toast toast-' + type;
  const iconClass = type === 'success' ? 'fa-circle-check' : 'fa-circle-xmark';
  
  // Implement toast structure
  toast.innerHTML = `
    <span class="toast-icon">
      <i class="fa-solid ${iconClass}"></i>
    </span>
    <div class="toast-body">
      <strong class="toast-title">${title}</strong>
      <span class="toast-msg">${msg}</span>
    </div>
    <button class="toast-close" aria-label="Dismiss">
      <i class="fa-solid fa-xmark"></i>
    </button>
  `;
  
  // Add interactive close icon
  toast.querySelector('.toast-close').addEventListener('click', () => dismissToast(toast));
  
  // Append toast in toast queue container
  toastContainer.appendChild(toast);

  // Enqueue/Show toast
  requestAnimationFrame(() => toast.classList.add('toast-visible'));

  // Dequeue/Hide toast [Automatically]
  const timer = setTimeout(() => dismissToast(toast), 5000);

}

// Hide toast
function dismissToast(toast) {
  toast.classList.remove('toast-visible');
  toast.addEventListener('transitionend', () => toast.remove(), { once: true });
}

// Handle form submission
contactForm.addEventListener('submit', (e) => {

  // Prevent page reloading
  e.preventDefault();
  
  // Update submit button status
  submitBtn.disabled = true;
  submitBtn.innerHTML = '<i class="fa-solid fa-spinner fa-spin"></i> Sending...';
  
  // Send auto-reply mail
  emailjs.sendForm(EMAILJS_SERVICE_ID, EMAILJS_TEMPLATE_ID, contactForm)
  .then(() => {
    // Show success toast
    showToast('success', 'Message Sent!', 'Thanks for reaching out - we will reply within 24 hours.');
    contactForm.reset();
  })
  .catch((err) => {
    // Show error toast
    console.error('EmailJS error:', err);
    showToast('error', 'Send Failed', 'Something went wrong. Please try again or email us directly.');
  })
  .finally(() => {
    // Update submit button status
    submitBtn.disabled = false;
    submitBtn.innerHTML = 'Send Message <i class="fa-solid fa-paper-plane"></i>';
  });

});
