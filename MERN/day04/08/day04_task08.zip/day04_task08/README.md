# SilkScript
This starter is a mix of HTML CSS JS codes for semi-interactive landing page of fake agency showcasing fake portfolio and contacts.


## Folder Structure
```
silkscript
|
|__ css                         # Folder contains all CSS stylesheets [you may add third-party files]
|   |__ reset.css               # RESET CSS stylesheet keeping same bare appearance for different browsers
|   |__ mini-framework.css      # CSS stylesheet for reusable components, effects, and theme properties
|   |__ main.css                # Main CSS stylesheet for customizing framework properties and layout
|   |__ todos.css               # Temporary CSS file contains comments for TODOs
|
|__ js                          # Folder contains all JS scripts [No need to pay attention to it]
|   |__ main.js                 # Main JS scripts for DOM manipulation and third-party libraries configuration
|
|__ favicons                    # Folder contains all favicon/logo images
|
|__ index.html                  # Webpage structure HTML file
```


## Page Structure/Components
00. **Metadata**
(title, icon, SEO, CDN links, stylesheets, scripts)

01. **Header**
(logo, navbar: bookmarks, CTA button, toggler, offcanvas)

02. **Hero Section**
(tag/badge, heading, sub, actions)

03. **Services Section**
(tag, heading, sub, grid, cards: icon, title, sub)

04. **Statistics Area**
(grid, odometers: number, symbol, type)

05. **Portfolio Section**
(tag, heading, sub, grid, cards: image, tag/badge, title, sub)

06. **Brands Banner**
(slider: track, logo, name)

07. **Contacts Section**
(tag, heading, sub, info (heading, list: icon, heading, contacts, social links), form (group: label, field, action))

08. **Floating Elements**
(go-to-top button, notification toasts: close icon, type, heading, sub)

09. **Footer**
(copyrights)


## Style Guide

### Font Pair
- Headings Font Family: [`JetBrains Mono`](https://fonts.google.com/specimen/JetBrains+Mono) (monospaced font)
- Body Font Family: [`Plus Jakarta Sans`](https://fonts.google.com/specimen/Plus+Jakarta+Sans) (Sans-Serif font)

### Breakpoints & Container
| Device      | Width Range       | Container Max Width |
| :---------- | :---------------- | :------------------ |
| Extra Small | `<= 575px`        | `100%`              |
| Small       | `576px ~ 767px`   | `540px`             |
| Medium      | `768px ~ 991px`   | `720px`             |
| Large       | `992px ~ 1199px`  | `960px`             |
| Extra Large | `1200px ~ 1399px` | `1140px`            |
| Ultra Large | `>= 1400px`       | `1320px`            |

### Theme Colors
| Usage                                 | Light Theme                    | Dark Theme                                      |
| :------------------------------------ | :----------------------------- | :---------------------------------------------- |
| page background color                 | `[hex: ffffff]`                | `[hex: 151515]`                                 |
| section/card background color         | `[hex: f4f6fb]`                | `[hex: 1a1a2e]`                                 |
| primary color tint                    | `[hex: ede9fe]`                | `[hex: d6c9ff]`                                 |
| primary base color                    | `[hex: 5b21b6]`                | `[hex: 6c63ff]`                                 |
| primary color shade                   | `[hex: 4c1d95]`                | `[hex: 4d46b6]`                                 |
| main text color                       | `[hex: 1e1b4b]`                | `[hex: f0f0f0]`                                 |
| alt/sub text color                    | `[hex: 64748b]`                | `[hex: 94a3b8]`                                 |
| border color                          | `[hex: e2e8f0]`                | `[hex: 2a2a3d]`                                 |
| semi transparent background           | `[rgba: 255, 255, 255, 0.65]`  | `[rgba: 0, 0, 0, 0.4]`                          |
| card shadow color                     | `[rgba: 91, 33, 182, 0.08]`    | `[rgba: 0, 0, 0, 0.35]`                         |
| hero section gradient                 | `[hex: f5f3ff], [hex: ede9fe]` | `[hex: 0d0d0d (start ~ center)], [hex: 1a1225]` |
| Luminary Co. project card gradient    | `[hex: ddd6fe], [hex: a78bfa]` | Same light theme colors                         |
| NexaStore project card gradient       | `[hex: bfdbfe], [hex: 6366f1]` | Same light theme colors                         |
| GreenPath project card gradient       | `[hex: d1fae5], [hex: 34d399]` | Same light theme colors                         |
| SunRise Café project card gradient    | `[hex: fde68a], [hex: f59e0b]` | Same light theme colors                         |
| HealthHive project card gradient      | `[hex: fecaca], [hex: f87171]` | Same light theme colors                         |
| Orbital Studio project card gradient  | `[hex: e0e7ff], [hex: 818cf8]` | Same light theme colors                         |


## Effects & Animations
00. Frosted Glass Background
01. Sticky Header
02. Sliding Offcanvas Toggling
03. Hovered Bookmarks Inwards Motion
04. Hero Gradient Background
05. CTA Hover/Activation
06. Smooth Scrolling
07. Card Lifting
08. Hovering Shadow
09. Odometer Rolling
10. Card Thumbnail Gradient
11. Brands Sliding Animation
12. Brand Logo/Name Hovering
13. Social Icons Highlighting
14. Form Input Field Focusing
15. Submission Form Status
16. Showing/Hiding Go-To-Top Button
17. Fixed Go-To-Top Button
18. Fixed Toasts Queue Container
19. Enqueue/Dequeue Toast
20. Toast Entering/Leaving